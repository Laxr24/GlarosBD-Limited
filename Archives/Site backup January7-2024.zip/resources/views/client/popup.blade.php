 <!-- Popup start -->
  <div id="popup-container" class="hidden transition fixed z-10 top-0 
h-screen w-screen flex justify-center items-center bg-gray-transparent">
    <div class=" w-[50vw] md:max-w-[30vw] rounded-md p-3 bg-gray-700">
      <a href="#" class="text-center block mt-4  mx-auto rounded-md 
bg-yellow-300 px-3 py-1 uppercase tracking-widest" 
onclick="closePopup()">Continue here</a>
      
      <a href="https://epoxyresin.glarosbd.com" target="_blank" 
class="text-center block mt-4  mx-auto rounded-md bg-blue-400 text-white 
font-bold px-3 py-1 uppercase tracking-widest">Visit Epoxy resin</a>

      <div class="relative justify-center flex">
        <button class="mt-2 inline-block rounded-md bg-red-400 
text-white font-bold px-4 py-1 " onclick="closePopup()">close 
(x)</button>
      </div>

    </div>
  </div>
  <!-- Popup end  -->




<!-- Up going switch -->
<a href="#" class="w-10 h-10 rounded-md fixed bottom-10 right-16 p-1 
transition hover:bg-yellow-300 active:bg-green-400 bg-green-500">
  <img width="100%" src="/assets/uparrow-0eaa141b.svg" alt="" srcset="">
</a>
<!-- Up going switch -->






  <!-- popup script -->
  <script>
    const popup = document.getElementById("popup-container"); 
    const popupTime = 10000

    setTimeout(()=>{
      popup.classList.remove("hidden")
    },popupTime)

    function closePopup(){
      popup.style.display = "none" 
    }
  </script>
  <!-- popup script end -->
