<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Glaros BD Limited</title>
    <link rel="shortcut icon" href="public/client/asset/favicon.svg" type="image/x-icon">

    <!-- CSS Sheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css"
        integrity="sha512-wnea99uKIC3TJF7v4eKk4Y+lMz2Mklv18+r4na2Gn1abDRPPOeef95xTzdwGD9e6zXJBteMIhZ1+68QC5byJZw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.26.1/axios.min.js"
        integrity="sha512-bPh3uwgU5qEMipS/VOmRqynnMXGGSRv+72H/N260MQeXZIK4PG48401Bsby9Nq5P5fz7hy5UGNmC/W1Z51h2GQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
        referrerpolicy="no-referrer" />


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;1,700&display=swap" rel="stylesheet">

    <style>
        * {
            scroll-behavior: smooth;
            scrollbar-width: 0;
            scrollbar-3dlight-color: none;
            scrollbar-base-color: none;
            scrollbar-color: none;
        }
    </style>

  <link href="public/client/assets/css/slider-style.css" rel="stylesheet"/>
 
</head>

<body>



<!-- Top header -->
    <div style="position: sticky; top:0; z-index: 100" class="mx-auto w-full p-4 bg-gray-700 md:grid md:grid-cols-2 grid gap-4 shadow-md">
        <div class=" ml-6 flex items-center ">
            <!-- Logo -->
            <div><img src="https://glarosbd.com/public/client/asset/favicon.svg" width="100%" alt="Glaros BD Logo"></div>
            <h4 class="text-white bold uppercase ml-3 font-bold">Glaros bd limited</h4>
        </div>


        <div class="md:grid md:grid-cols-3 justify-center">
            <div></div>
            <div></div>
            <a href="#contact" class="px-4 flex text-center justify-center py-1 rounded-md items-center bg-red-500 hover:bg-red-300 transition-all hover:text-gray-500 text-white uppercase font-bold">Contact seller</a>
        </div>
    </div>
<!-- End de Top header -->

<!-- Top Section -->
<div id="top_header"></div>
<!-- end de Top Section -->

<!-- Slider start -->
  <div class="swiper" data-aos="zoom-fade-in" data-aos-easing="ease-in-back" data-aos-delay="300">
    <div class="swiper-wrapper">
      <!-- Slide 1 start  -->
      <div class="swiper-slide flex md:justify-end pr-6 justify-center items-center bg-yellow-500 bg-cover bg-center bg-no-repeat"
        style="background-image: url('/public/client/uploads/WEB01.jpg');">

        <div class="md:max-w-2xl w-[80%] p-6 rounded-md bg-gray-700 opacity-80">

          <h1 class="text-white text-4xl font-bold uppercase tracking-widest">glaros bd limited</h1>
          <p class="text-white mt-4">We're the best and biggest epoxy resin and industry grade construction chemical supplier in Bangladesh with a wide range of services. Our products are tested and trusted throughout the industrial community.</p>

          <a href="#products"
            class=" inline-block hover:bg-green-200 transition bg-yellow-300 px-4 py-2 rounded-md shadow md font-bold uppercase tracking-widest text-center mt-4">Learn
            more</a>
        </div>


      </div>
      <!-- Slide 1 end -->
      <!-- Slide 2 start -->
      <div class="swiper-slide flex md:justify-end pr-6 justify-center items-center bg-yellow-500 bg-cover bg-center bg-no-repeat"
        style="background-image: url('/public/client/uploads/WEB03.jpeg');">

        <div class="md:max-w-2xl w-[80%] p-6 rounded-md bg-gray-700 opacity-90">

          <h1 class="text-white text-4xl font-bold uppercase tracking-widest">Epoxy resin</h1>
          <p class="text-white mt-4">Epoxy Resin Supplier is a sister concern of Glaros BD Limited. The biggest epoxy resin supplier in Bangladesh. With epoxy resin you'll find your desired resin products, solutions, crafting materials and much more to find more...</p>

          <a href="https://epoxyresin.glarosbd.com"
            class=" inline-block hover:bg-green-200 transition bg-yellow-300 px-4 py-2 rounded-md shadow md font-bold uppercase tracking-widest text-center mt-4">Learn
            more</a>
        </div>
      </div>
      <!-- Slide 2 end -->
   </div>
  </div>

  <!-- Slider end -->



        <!-- ribbon -->
        <div
            class="max-w-lg mx-auto md:px-92 text-center  py-4 flex justify-around shadow-md mt-6 animate__animated animate__fadeInUp">
            <p class="text-center uppercase">resin</p>
            <p class="text-center uppercase">silicon</p>
            <p class="text-center uppercase">silicate</p>
            <p class="text-center uppercase">and more</p>

        </div>
        <!-- end of ribbon -->

<!-- epoxy ribbon -->
       <!-- <a href="https://www.epoxyresin.glarosbd.com" target="_blank" class="text-center uppercase"><div
            class="md:max-w-lg w-64 mx-auto md:px-92 bg-yellow-400 text-center  py-4 flex justify-around shadow-md mt-4 animate__animated animate__fadeInUp">
            Click here to learn more EPOXY
        </div></a> -->
        <!-- end of epoxy ribbon -->






        <!-- Scroll indicator  -->
        <img src="public/client/asset/mouseScroll.png" alt=""
            class="mt-5 mx-auto animate__fadeInUp animate__animated animate__bounce animate__infinite 	infinite animate__slow">
        <!-- end Scroll indicator  -->
    </div>
    <!-- End of the Hero Container -->



    <!-- product gallery -->
    <div id="products" class="container mx-auto bg-gray-50 my-26 px-6 py-10 md:px-16 animate__animated animate__fadeInUp">
        <h1 class="uppercase text-center my-4 text-gray-600 "
            style="letter-spacing: 2px; font-size: 2em;font-weight: 400;font-family: 'PT Serif', serif;">Products
        </h1>
        <div class="grid md:grid-cols-4 gap-8">

            @foreach ($products as $product )
                 <div class="md:max-w-sm">
                <img src="{{$product['image_path']}}" class="w-full" alt="">
                <a href="#{{$product['name']}}" class="block text-center uppercase px-4 mt-2 py-2 border border-black">learn more about
                    {{$product['name']}}</a>
            </div>
            <!-- end of single card -->
            @endforeach
            <!-- single card -->
           


        </div>
    </div>
    <!-- end de product gallery -->








    {{-- Descriptive product overview  --}}
    <section>
        <h1 class="uppercase text-center my-4 text-gray-600 "
            style="letter-spacing: 2px; font-size: 2em; font-weight: 400; font-family: 'PT Serif', serif;">product
            overview
        </h1>


       @foreach ($products as $product)
           @if($product['side'] == "true")
 {{-- Right side  --}}
                <!-- Single descriptive produt information -->
        <div class="my-24" id="{{$product['name']}}">
            <div class="container p-6 md:p-10  mx-auto grid md:grid-cols-2 gap-3">
                <div class=" max-w-md"><img class="mx-auto" src="{{$product['image_path']}}" alt=""></div>
                <!-- content -->
                <div class="max-w-md px-3">
                    <h1 class="uppercase text-center px-4 py-2 border border-black"
                        style="font-size: 1.4em; font-weight: 400; letter-spacing: 2px;">{{$product['name']}}</h1>

                    <hr class="my-3 border-4 border-green-600">

                   
                        {{$product['description']}}
                    

                    <div class="py-6 flex">
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">Contact</a>
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">order</a>
                    </div>
                </div>
                <!-- end content -->

            </div>
            <img src="public/client/asset/description_arraow_purple.png" alt="" class="float-right">
        </div>
        <!-- End of the Single descriptive produt information -->
        {{-- Right side  --}}



           @else
                        {{-- Left side --}}
        <!-- Single descriptive produt information -->
        <div class="my-16" id="{{$product['name']}}">
            <div class="container p-6 md:p-10  mx-auto grid md:grid-cols-2 gap-3">
                <div class=" max-w-md"><img class="mx-auto" src="{{$product['image_path']}}" alt=""></div>
                <!-- content -->
                <div class="max-w-md px-3">
                    <h1 class="uppercase text-center px-4 py-2 border border-black"
                        style="font-size: 1.4em; font-weight: 400; letter-spacing: 2px;">{{$product['name']}}</h1>

                    <hr class="my-3 border-4 border-yellow-600">

                    
                        {{$product['description']}}
                    

                    <div class="py-6 flex">
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">Contact</a>
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">order</a>
                    </div>
                </div>
                <!-- end content -->

            </div>
            <img src="public/client/asset/description_arraow_orange.png" alt="" class="float-left">
        </div>
        <!-- End of the Single descriptive produt information -->
        {{-- Left side --}}
           @endif
       @endforeach

    </section>


 <!-- Popup start -->
  <div id="popup-container" class="hidden transition fixed z-10 top-0 h-screen w-screen flex justify-center items-center bg-gray-transparent">
    <div class=" w-[50vw] md:max-w-[30vw] rounded-md p-3 bg-gray-700">
      <a class="cursor-pointer text-center block mt-4  mx-auto rounded-md bg-yellow-300 px-3 py-1 uppercase tracking-widest" onclick="closePopup()">Continue here</a>
      
      <a href="https://epoxyresin.glarosbd.com" target="_blank" class="text-center block mt-4  mx-auto rounded-md bg-blue-400 text-white font-bold px-3 py-1 uppercase tracking-widest">Visit Epoxy resin</a>

      <div class="relative justify-center flex">
        <button class="mt-2 inline-block rounded-md bg-red-400 text-white font-bold px-4 py-1 " onclick="closePopup()">close (x)</button>
      </div>

    </div>
  </div>
  <!-- Popup end  -->




<!-- Up going switch -->
<a href="#top_header" class="w-10 h-10 rounded-md fixed bottom-10 left-16 p-1 transition hover:bg-yellow-300 active:bg-green-400 bg-green-500">
  <img width="100%" src="/public/client/uploads/uparrow.svg" alt="" srcset="">
</a>
<!-- Up going switch -->






  <!-- popup script -->
  <script>
    const popup = document.getElementById("popup-container"); 
    const popupTime = 5000

    setTimeout(()=>{
      popup.classList.remove("hidden")
    },popupTime)

    function closePopup(){
      popup.style.display = "none" 
    }
  </script>
  <!-- popup script end -->




    <!-- footer -->
    <footer>
        <div class="bg-gray-600 text-center md:text-left md:px-24  px-6 mt-6 text-gray-300 py-24">
            <div class="md:flex justify-around">
                <div class="my-4">
                    <h1 class="text-3xl text-white">Contact</h1>
                    <div class="max-w-md" id="contact">
                        <ul class="my-3 md:text-left">
                            <li class="my-4"><i class="fa-solid fa-phone mr-2"><span class="tracking-wider"> Sales: </span></i>
<a class="inline"
                                    href="tel:+8801919506070">+8801919-506070</a></li>
<li class="my-4"><i class="fa-solid fa-phone mr-2"><span class="tracking-wider"> Support: </span></i>
<a class="inline" href="tel:+880 1407-020425">+880 1407-020425</a>
</li>


                            <li class="my-4"><i class="fa-solid fa-at mr-2"></i><a
                                    href="mailto:info@glarosbd.com">info@glarosbd.com</a></li>



                        </ul>
                    </div>
                </div>
                <div class="my-4">
                    <h1 class="text-3xl text-white">Address</h1>
                    <div class="md:flex items-center mt-5 max-w-md">
                        <span><img src="public/client/asset/arrow.svg" class="mx-auto w-10 md:mr-10 md:pr-4 py-4 "
                                alt=""></span>
                        <a href="https://goo.gl/maps/wGRMJQJ5HTnfogFo9" class="" target="_blank">
Kuril , KA- 39/2, Progoti Sarani Road, Vatara, Dhaka-1229
                        </a>
                    </div>

<div style="font-size:2em; margin-top:1em; ">
<a href="https://www.facebook.com/glarosbdltd" class="mr-2 "> <i class="fab fa-facebook-square"></i></a>
<a href="https://www.instagram.com/epoxyresinbd/" class="mr-2"> <i class="fab fa-instagram"></i></a>
<a href="https://wa.link/8u64mm" class="mr-2"> <i class="fab fa-whatsapp"></i></a>
<a href="https://www.youtube.com/channel/UC6onrrBOPCAVJsSN1bdOxxw" class="mr-2"> <i class="fab fa-youtube"></i></a>

</div>
                </div>
            </div>
        </div>
        <div class="bg-gray-800 text-center tracking-large text-gray-500 py-2">
            <p>copyright &copy; glarosbd 2022</p>
        </div>
    </footer>
    <!-- end footer -->

<script src="public/client/assets/js/slider.js" />

<!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>
    <!-- Your Chat Plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "326334491324858");
      chatbox.setAttribute("attribution", "biz_inbox");
    </script>

    <!-- Your SDK code -->
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v13.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>


</body>

</html>