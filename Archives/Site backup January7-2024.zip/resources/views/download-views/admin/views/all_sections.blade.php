@include("admin.views.sections.dashboard")
@include("admin.views.sections.single_section")
@include("admin.views.sections.setting")
@include("admin.views.sections.addProduct")
@include("admin.views.sections.editProduct")
@include("admin.views.sections.siteSetting")


<script>
    tabMaker("tab", false)
</script>