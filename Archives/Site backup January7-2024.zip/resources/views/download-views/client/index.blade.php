<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Glaros BD Limited</title>
    <link rel="shortcut icon" href="public/client/asset/favicon.svg" type="image/x-icon">

    <!-- CSS Sheets -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css"
        integrity="sha512-wnea99uKIC3TJF7v4eKk4Y+lMz2Mklv18+r4na2Gn1abDRPPOeef95xTzdwGD9e6zXJBteMIhZ1+68QC5byJZw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.26.1/axios.min.js"
        integrity="sha512-bPh3uwgU5qEMipS/VOmRqynnMXGGSRv+72H/N260MQeXZIK4PG48401Bsby9Nq5P5fz7hy5UGNmC/W1Z51h2GQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
        referrerpolicy="no-referrer" />


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=PT+Serif:ital,wght@0,400;1,700&display=swap" rel="stylesheet">

    <style>
        * {
            scroll-behavior: smooth;
            scrollbar-width: 0;
            scrollbar-3dlight-color: none;
            scrollbar-base-color: none;
            scrollbar-color: none;
        }
    </style>
    
    

</head>

<body>

    <!-- Hero Container -->
    <div class="">
        <!-- Hero -->
        <div class="md:mt-36 mt-8">
            <div class="grid md:grid-cols-2 md:p-2">
                <!-- img -->
                <div class=" flex justify-center items-center p-2  animate__animated animate__fadeIn">
                    <img src="public/client/asset/hero_img.png" alt="">
                </div>
                <!-- end of the img -->

                <!-- Content -->
                <div class="max-w-md  mt-4">
                    <h1 class="uppercase md:text-left text-center  font-bold"
                        style="letter-spacing: 1.5rem; font-size: 2rem;font-weight: 500;">glaros bd</h1>
                    <div class="md:flex mt-8 mx-auto animate__animated animate__fadeInRight">
                        <img class="flex-2 mb-5 mx-auto w-24 md:w-full" src="public/client/asset/icon.svg" alt="">
                        <div class="flex justify-center items-center">
                            <p class="text-justify flex-3 mx-auto md:text-left px-8 text-sm"
                                style="letter-spacing: 1px;">
                                 We're the best epoxy resin and industry grade construction chemical supplier in Bangladesh with a wide range of services. Our products are tested and trusted throughout the industrial community. 
  
                            </p>
                        </div>
                    </div>
                </div>
                <!-- End of the Content -->
            </div>

        </div>
        <!-- End of the Hero -->

        <!-- ribbon -->
        <div
            class="max-w-lg mx-auto md:px-92 text-center  py-4 flex justify-around shadow-md mt-24 animate__animated animate__fadeInUp">
            <p class="text-center uppercase">resin</p>
            <p class="text-center uppercase">silicon</p>
            <p class="text-center uppercase">silicate</p>
            <p class="text-center uppercase">and more</p>

        </div>
        <!-- end of ribbon -->


        <!-- Scroll indicator  -->
        <img src="public/client/asset/mouseScroll.png" alt=""
            class="mt-10 md:mt-24 mx-auto animate__fadeInUp animate__animated animate__bounce animate__infinite 	infinite animate__slow">
        <!-- end Scroll indicator  -->
    </div>
    <!-- End of the Hero Container -->



    <!-- product gallery -->
    <div class="container mx-auto bg-gray-50 my-36 px-6 py-10 md:px-16 animate__animated animate__fadeInUp">
        <h1 class="uppercase text-center my-4 text-gray-600 "
            style="letter-spacing: 2px; font-size: 2em;font-weight: 400;font-family: 'PT Serif', serif;">Products
        </h1>
        <div class="grid md:grid-cols-4 gap-8">

            @foreach ($products as $product )
                 <div class="md:max-w-sm">
                <img src="{{$product['image_path']}}" class="w-full" alt="">
                <a href="#{{$product['name']}}" class="block text-center uppercase px-4 mt-2 py-2 border border-black">learn more about
                    {{$product['name']}}</a>
            </div>
            <!-- end of single card -->
            @endforeach
            <!-- single card -->
           


        </div>
    </div>
    <!-- end de product gallery -->








    {{-- Descriptive product overview  --}}
    <section>
        <h1 class="uppercase text-center my-4 text-gray-600 "
            style="letter-spacing: 2px; font-size: 2em; font-weight: 400; font-family: 'PT Serif', serif;">product
            overview
        </h1>


       @foreach ($products as $product)
           @if($product['side'] == "true")
 {{-- Right side  --}}
                <!-- Single descriptive produt information -->
        <div class="my-24" id="{{$product['name']}}">
            <div class="container p-6 md:p-10  mx-auto grid md:grid-cols-2 gap-3">
                <div class=" max-w-md"><img class="mx-auto" src="{{$product['image_path']}}" alt=""></div>
                <!-- content -->
                <div class="max-w-md px-3">
                    <h1 class="uppercase text-center px-4 py-2 border border-black"
                        style="font-size: 1.4em; font-weight: 400; letter-spacing: 2px;">{{$product['name']}}</h1>

                    <hr class="my-3 border-4 border-green-600">

                   
                        {{$product['description']}}
                    

                    <div class="py-6 flex">
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">Contact</a>
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">order</a>
                    </div>
                </div>
                <!-- end content -->

            </div>
            <img src="public/client/asset/description_arraow_purple.png" alt="" class="float-right">
        </div>
        <!-- End of the Single descriptive produt information -->
        {{-- Right side  --}}



           @else
                        {{-- Left side --}}
        <!-- Single descriptive produt information -->
        <div class="my-16" id="{{$product['name']}}">
            <div class="container p-6 md:p-10  mx-auto grid md:grid-cols-2 gap-3">
                <div class=" max-w-md"><img class="mx-auto" src="{{$product['image_path']}}" alt=""></div>
                <!-- content -->
                <div class="max-w-md px-3">
                    <h1 class="uppercase text-center px-4 py-2 border border-black"
                        style="font-size: 1.4em; font-weight: 400; letter-spacing: 2px;">{{$product['name']}}</h1>

                    <hr class="my-3 border-4 border-yellow-600">

                    
                        {{$product['description']}}
                    

                    <div class="py-6 flex">
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">Contact</a>
                        <a href="#contact" class="  px-4 py-2 rounded-md shadow m-4 uppercase">order</a>
                    </div>
                </div>
                <!-- end content -->

            </div>
            <img src="public/client/asset/description_arraow_orange.png" alt="" class="float-left">
        </div>
        <!-- End of the Single descriptive produt information -->
        {{-- Left side --}}
           @endif
       @endforeach

    </section>







    <!-- footer -->
    <footer>
        <div class="bg-gray-600 text-center md:text-left md:px-24  px-6 mt-6 text-gray-300 py-24">
            <div class="md:flex justify-around">
                <div class="my-4">
                    <h1 class="text-3xl text-white">Contact</h1>
                    <div class="max-w-md" id="contact">
                        <ul class="my-3 md:text-left">
                            <li class="my-4"><i class="fa-solid fa-phone mr-2"></i><a class="inline"
                                    href="tel:+8801919506070">+8801919-506070</a></li>
                            <li class="my-4"><i class="fa-solid fa-at mr-2"></i><a
                                    href="mailto:info@glarosbd.com">info@glarosbd.com</a></li>

                        </ul>
                    </div>
                </div>
                <div class="my-4">
                    <h1 class="text-3xl text-white">Address</h1>
                    <div class="md:flex items-center mt-5 max-w-md">
                        <span><img src="public/client/asset/arrow.svg" class="mx-auto w-10 md:mr-10 md:pr-4 py-4 "
                                alt=""></span>
                        <a href="https://goo.gl/maps/wGRMJQJ5HTnfogFo9" class="" target="_blank">

                            ka-57/4 (3rd Floor), Kuril Chowrasta, Pragati Sharani Road, Vatara,
                            Dhaka-1229
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="bg-gray-800 text-center tracking-large text-gray-500 py-2">
            <p>copyright &copy; glarosbd 2022</p>
        </div>
    </footer>
    <!-- end footer -->


<!-- Messenger Chat Plugin Code -->
    <div id="fb-root"></div>
    <!-- Your Chat Plugin code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "326334491324858");
      chatbox.setAttribute("attribution", "biz_inbox");
    </script>

    <!-- Your SDK code -->
    <script>
      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v13.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>


</body>

</html>