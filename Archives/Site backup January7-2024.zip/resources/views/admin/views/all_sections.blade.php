@include("admin.views.sections.dashboard")
@include("admin.views.sections.single_section")

@if (Auth::user()->role == "Admin")
    @include("admin.views.sections.setting")
@endif


@include("admin.views.sections.addProduct")

@if (Auth::user()->role == "Admin")
    @include("admin.views.sections.editProduct")
@endif

@include("admin.views.sections.siteSetting")


<script>
    tabMaker("tab", false)
</script>