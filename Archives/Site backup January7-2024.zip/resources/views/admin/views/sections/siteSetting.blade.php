@if (Auth::user()->role == "Admin")
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper tab-6">
      <!-- Content Header (Page header) -->
      <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Single</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">single</li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
      </div>
      <!-- /.content-header -->
      <!-- Main content -->
      <section class="content">
          <div class="p-4 h-auto w-full rounded-md shadow-lg bg-yellow-400">
              <p class="p-2 font-mono text-black">I am a Setting component</p>
          </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->


@endif