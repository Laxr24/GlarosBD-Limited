<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ops! Error</title>
    <style>
        .container{
            display: flex; 
            justify-content: center; 
            align-items: center; 
            height: 90vh;
            width: 90;
            background: rgb(250, 253, 253) ; 
            
        }
        h1{
            font-family: sans-serif; 
            font-weight: 100; 
            font-size: 3em; 
            color: rgb(65, 65, 65); 
        }
        p{
            text-align: center; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Ops! 404</h1>
    </div>


    <footer>
        <p>copyright@2022</p>
    </footer>
</body>
</html>